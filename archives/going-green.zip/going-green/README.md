### Planning Green changes

This project is trying to turn simple webpages into a Progressive Web App.





### Installation Steps

1.  Install Node
2.  Run "npm install -g http-server"
4.  Run "http-server"

All libraries and files that are necessary are in the resources folder. No need to run bower or any build tasks.
